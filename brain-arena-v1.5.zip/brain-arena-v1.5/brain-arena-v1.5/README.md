# Brain Arena – Zunex Studios
Offline football quiz. Pure HTML/CSS/JS in `www/index.html`, no external files.

Test in browser: open `www/index.html`.

Build Android:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android` -> Run, or Build > Build APK in Android Studio.

After editing `www/`, run `npx cap sync android` again.
Add questions in the `RAW` list: `category|difficulty|question|correct|wrong|wrong|wrong` (H/C/P/T, e/m/h).

## v1.1 additions
- **Daily missions** – 3 new missions each day (seeded by date, works offline), claim XP rewards + all-clear bonus.
- **Daily 10 challenge** – 10 fixed questions per day (3 easy, 4 medium, 3 hard). XP per correct answer + perfect bonus; replays are practice only.
- **Premium menu** – +50% XP, 50/50 lifeline, +5s per question, gold theme. Currently a local test unlock: set `BILLING_READY=true` and implement the purchase in `www/index.html` (`pmGo` handler / `setPremium`) with Google Play Billing before release.
- **Offline save** – progress stored in `localStorage` (`brainarena.v2` + backup copy `brainarena.bak`), auto-migrates v1 saves.


## BRAIN ARENA update
- Expanded offline question bank: 319 football questions.
- Added animated question/answer presentation and country flags / club monogram badges.
- Existing daily challenge, missions, XP, premium test mode, records and offline save are preserved.


## Question images (v1.2)

Question screens can fetch matching, openly licensed football club/player images from Wikimedia Commons. Images are downloaded on first view and cached on the device, so previously viewed images can display offline later. An internet connection is needed the first time each image is fetched. Image credits, license labels and source links are shown below the question image. If no suitable image is found or the device is offline, a built-in football icon placeholder is shown.


## New player modes (v1.3)
- Who is better? compares two players from the same position (goalkeeper, defender, midfielder or forward).
- Guess the country: identify a player's national team.
- Player's clubs: select a club the player has represented.
- Player photos are requested from Wikimedia Commons and cached on the device when available; first-time image loading requires internet. Photo author and licence are shown in the game.


## v1.5
- Zunex Studios logo splash screen on launch (tap to skip).
- Turkish / English language menu (top-left), all questions and answers translated.
- Country flags (SVG) on answer options; generated footballer avatars when photos are unavailable.
- New modes: Survival, Guess the player (clues), Two-player duel, Leaderboard.
- Question history: modes avoid repeating recently asked questions.
- Note: the Leaderboard shared board only works on the claude.ai artifact page; in the Android build it shows this device's best score only.
